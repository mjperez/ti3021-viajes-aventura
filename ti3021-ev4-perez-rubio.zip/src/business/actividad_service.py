"""Service Layer para Actividades

Encapsula la lógica de negocio relacionada con actividades turísticas.
Intermediario entre la UI y el DAO para mantener separación de capas.
"""

from src.dao.actividad_dao import ActividadDAO
from src.dto.actividad_dto import ActividadDTO
from src.utils.exceptions import ValidacionError


class ActividadService:
    """Servicio para gestión de actividades turísticas."""
    
    def __init__(self):
        """Inicializa el servicio con su DAO."""
        self.actividad_dao = ActividadDAO()
    
    def crear_actividad(
        self,
        nombre: str,
        descripcion: str,
        duracion_horas: int,
        precio_base: int,
        destino_id: int
    ) -> ActividadDTO:
        """Crea una nueva actividad con validaciones. Retorna ActividadDTO con la actividad creada"""
        # Validaciones de negocio
        if not nombre or not nombre.strip():
            raise ValidacionError("El nombre de la actividad no puede estar vacío")
        if not descripcion or not descripcion.strip():
            raise ValidacionError("La descripción no puede estar vacía")
        if duracion_horas <= 0:
            raise ValidacionError("La duración debe ser mayor a 0 horas")
        if precio_base < 0:
            raise ValidacionError("El precio base no puede ser negativo")
        if destino_id <= 0:
            raise ValidacionError("Debe especificar un destino válido")
        
        # Crear DTO y delegar al DAO
        actividad = ActividadDTO(
            id=None,
            nombre=nombre.strip(),
            descripcion=descripcion.strip(),
            duracion_horas=duracion_horas,
            precio_base=precio_base,
            destino_id=destino_id
        )
        
        actividad_id = self.actividad_dao.crear(actividad)
        actividad.id = actividad_id
        return actividad
    
    def obtener_actividad(self, actividad_id: int) -> ActividadDTO | None:
        """Obtiene una actividad por ID. Retorna ActividadDTO o None si no existe"""
        if actividad_id <= 0:
            raise ValidacionError("El ID de la actividad debe ser mayor a 0")
        
        return self.actividad_dao.obtener_por_id(actividad_id)
    
    def listar_todas_actividades(self) -> list[ActividadDTO]:
        """Lista todas las actividades activas. Retorna Lista de ActividadDTO"""
        return self.actividad_dao.listar_todas()
    
    def listar_todas_actividades_admin(self) -> list[dict]:
        """Lista TODAS las actividades incluyendo inactivas (para admin). Retorna Lista de dicts con info de actividades"""
        return self.actividad_dao.listar_todas_admin()
    
    def listar_actividades_por_destino(self, destino_id: int) -> list[ActividadDTO]:
        """Lista actividades activas de un destino específico. Retorna Lista de ActividadDTO del destino"""
        if destino_id <= 0:
            raise ValidacionError("El ID del destino debe ser mayor a 0")
        
        return self.actividad_dao.listar_por_destino(destino_id)
    
    def reactivar_actividad(self, actividad_id: int) -> bool:
        """Reactiva una actividad desactivada. Retorna True si se reactivó correctamente"""
        if actividad_id <= 0:
            raise ValidacionError("El ID de la actividad debe ser mayor a 0")
        return self.actividad_dao.reactivar(actividad_id)
    
    def actualizar_actividad(
        self,
        actividad_id: int,
        nombre: str,
        descripcion: str,
        duracion_horas: int,
        precio_base: int,
        destino_id: int
    ) -> ActividadDTO:
        """Actualiza una actividad existente. Retorna ActividadDTO actualizada"""
        # Validaciones
        if actividad_id <= 0:
            raise ValidacionError("El ID de la actividad debe ser mayor a 0")
        if not nombre or not nombre.strip():
            raise ValidacionError("El nombre de la actividad no puede estar vacío")
        if not descripcion or not descripcion.strip():
            raise ValidacionError("La descripción no puede estar vacía")
        if duracion_horas <= 0:
            raise ValidacionError("La duración debe ser mayor a 0 horas")
        if precio_base < 0:
            raise ValidacionError("El precio base no puede ser negativo")
        if destino_id <= 0:
            raise ValidacionError("Debe especificar un destino válido")
        
        # Verificar existencia
        actividad_existente = self.actividad_dao.obtener_por_id(actividad_id)
        if not actividad_existente:
            raise ValidacionError(f"No existe una actividad con ID {actividad_id}")
        
        # Actualizar
        actividad = ActividadDTO(
            id=actividad_id,
            nombre=nombre.strip(),
            descripcion=descripcion.strip(),
            duracion_horas=duracion_horas,
            precio_base=precio_base,
            destino_id=destino_id
        )
        
        success = self.actividad_dao.actualizar(actividad_id, actividad)
        if not success:
            raise ValidacionError(f"No se pudo actualizar la actividad con ID {actividad_id}")
        return actividad
    
    def eliminar_actividad(self, actividad_id: int) -> bool:
        """Elimina una actividad. Retorna True si se eliminó correctamente"""
        if actividad_id <= 0:
            raise ValidacionError("El ID de la actividad debe ser mayor a 0")
        
        # Verificar existencia
        actividad_existente = self.actividad_dao.obtener_por_id(actividad_id)
        if not actividad_existente:
            raise ValidacionError(f"No existe una actividad con ID {actividad_id}")
        
        return self.actividad_dao.eliminar(actividad_id)
